import torch
from torch import nn, optim
import pandas as pd
import numpy as np
import random
from torch.nn.parameter import Parameter

df = pd.read_excel('002156.xlsx')
# data=df.values[:420,1:6].astype(float)
# label=(df.values[:420,3].astype(float))[::-1]
# np.savetxt('label.csv', label, delimiter = ',')
# mx=np.max(data,axis=0)
# data=data/mx
# data=data[::-1]
# np.savetxt('data.csv', data, delimiter = ',')
label = np.loadtxt(open("label.csv"),delimiter=",")
data = np.loadtxt(open("data.csv"),delimiter=",")

data=torch.from_numpy(data).float()
label=torch.from_numpy(label)


class GRUcell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(GRUcell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.Wz=Parameter(torch.FloatTensor(input_size+hidden_size, hidden_size))
        self.Wr=Parameter(torch.FloatTensor(input_size+hidden_size, hidden_size))
        self.W=Parameter(torch.FloatTensor(input_size+hidden_size, hidden_size))
        self.sigmoid=nn.Sigmoid()
        self.tanh=nn.Tanh()

    def forward(self,xt,hidden):
        zt=self.sigmoid(torch.mm(torch.cat((hidden,xt),dim=1),self.Wz))
        rt=self.sigmoid(torch.mm(torch.cat((hidden,xt),dim=1),self.Wr))
        h_t=self.tanh(torch.mm(torch.cat((rt*hidden,xt),dim=1),self.W))
        ht=(1-zt)*hidden+zt*h_t
        return ht


class GRUmodel(nn.Module):
    def __init__(self,input_dim,hidden_dim):
        super(GRUmodel, self).__init__()
        self.hidden_dim = hidden_dim
        self.gru_cell = GRUcell(input_dim, hidden_dim)
        self.fc=nn.Linear(20,1)

    def forward(self,x):
        hidden=torch.zeros((1,self.hidden_dim))
        for seq in range((x.shape)[0]):
            hidden=self.gru_cell(torch.unsqueeze(x[seq],0),hidden)
        outputs=self.fc(hidden)
        return outputs




model=GRUmodel(5,20)
lossfun=nn.MSELoss()
optimizer = optim.Adam(model.parameters(),
                       lr=.01, weight_decay=5e-4)


sequence=list(range(420))[20:]
random.shuffle(sequence)


for epoch in range(10):
    for i in sequence:
        model.train()
        optimizer.zero_grad()
        input=data[i - 20 + 1: i + 1]
        output=model(input)
        output=torch.squeeze(output,1)
        target=torch.tensor([1]).float()
        target[0]=(label[i]-label[i-1])/label[i-1]
        loss=lossfun(output,target)
        print('loss={:.8f}'.format(loss.item()))
        loss.backward()
        optimizer.step()
        # output=model(input)
